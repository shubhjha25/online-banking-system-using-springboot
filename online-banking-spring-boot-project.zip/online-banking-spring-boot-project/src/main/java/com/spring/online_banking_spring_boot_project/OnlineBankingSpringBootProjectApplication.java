package com.spring.online_banking_spring_boot_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineBankingSpringBootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBankingSpringBootProjectApplication.class, args);
	}

}
