package com.spring.online_banking_spring_boot_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBankingSpringBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
